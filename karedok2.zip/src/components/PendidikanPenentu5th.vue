<template>
    <div class="full-page white-background">

        <div class="quicksand-font">
            <!-- <div data-aos="fade-up" data-aos-once="false">
                <div class="mt-8 md:mt-2 text-2xl md:text-6xl sm:text-2xl font-extrabold text-white text-center">
                    Pendidikan Jadi Penentu </div>
            </div> -->
            <div class="grid grid-cols-12 gap-4 ">
                <div
                    class="col-start-2 col-end-12 md:col-start-4 md:col-end-10 sm:col-start-2 sm:col-end-12 col-span-6 flex flex-col items-center">
                    <div data-aos="fade-up" data-aos-once="false">
                        <div
                            class="mt-8 md:mt-2 text-2xl md:text-6xl sm:text-2xl font-extrabold judul4th text-center text-white">
                            Pendidikan Jadi Penentu</div>
                    </div>
                </div>
                <div class="col-start-3 col-end-11 md:col-start-4 md:col-end-10  flex flex-col items-center">
                    <div data-aos="fade-up" data-aos-once="false">
                        <div
                            class="w-[12rem] md:w-[30rem] sm:w-[12rem] h-[12rem] md:h-[30rem] sm:h-[12rem] hvr-float mb-2 md:md-16 sm:mb-2">
                            <lottie-player
                                src="https://lottie.host/a9ccd6e7-34f2-49ec-8169-e4e87d982f8c/rVxYM6NH7J.json"
                                background="transparent" speed="1" class=" hoverable " direction="1" mode="normal" loop
                                autoplay>
                            </lottie-player>
                        </div>
                    </div>
                    <br><br>
                    <div data-aos="fade-up" data-aos-once="false">
                        <p class="text-[14px] md:text-[24px] sm:text-[14px] mt-4 text-left">
                            Penelitian menyebutkan pendidikan berpengaruh secara signifikan pada tingkat NEET (Bynner &
                            Parsons, 2002).
                            Pendidikan memang selalu menjadi faktor utama pemutus rantai kemiskinan, yang diawali dari
                            pemutus
                            rantai menganggur.
                            <br><br>
                            <!-- Kamingsun kecil adalah seorang anak laki-laki yang lahir dan tumbuh besar dalam gang sempit di
                        pinggiran Ibu kota. Keseharian ayahnya adalah ojek, sedangkan ibunya berjualan pop ice boba
                        paling terkenal se-Kecamatan.
                        <br><br> -->
                            Memasuki masa sekolah, Kamingsun disekolahkan di SD, SMP dan SMK dekat rumahnya.
                            Maksud
                            orang tua Kamingsun menyekolahkannya ke SMK adalah agar setelah lulus SMK, ia langsung
                            bekerja.
                            <br><br>
                            Namun, kenyataannya tidak seperti yang orang tua Kamingsun pikirkan. Tingkat pengangguran
                            terbuka tertinggi tahun 2020 berdasarkan tingkat pendidikan jatuh pada lulusan SMK sebesar
                            13,55, yang artinya, terdapat <span class="md:text-3xl sm:text-xl"> <strong> 13 sampai 14
                                    dari 100
                                    penduduk angkatan
                                    kerja lulusan SMK tahun 2020
                                    menganggur.</strong></span> Tahun 2021 dan 2022, tingkat pengangguran terendah
                            adalah
                            lulusan universitas dan diploma,
                            artinya di era saat ini,<span class="md:text-3xl sm:text-xl"> <strong> menempuh pendidikan
                                    sampai kuliah
                                    menjadi hal yang penting. </strong></span>
                            <br><br>


                            <!-- <table class="table-fixed text-[14px] md:text-[24px] sm:text-[14px]">
                            <caption class="caption-bottom">
                                Table 3.1: Professional wrestlers and their signature moves.
                            </caption>
                            <thead>
                            <tr>
                                <th rowspan="2">Tingkat Pendidikan</th>
                                <th colspan="3">Tingkat Pengangguran Terbuka Berdasarkan Tingkat Pendidikan</th>
                            </tr>
                            <tr>
                                <th>2020</th>
                                <th>2021</th>
                                <th>2022</th>
                            </tr>
                        </thead>
                            <tr>
                                <td>Tidak/Belum Pernah Sekolah/Belum Tamat & Tamat SD</td>
                                <td>3.61</td>
                                <td>3.61</td>
                                <td>3.59</td>
                            </tr>
                            <tbody>
                            <tr>
                                <td>SMP</td>
                                <td>6.46</td>
                                <td>6.45</td>
                                <td>5.95</td>
                            </tr>
                            <tr>
                                <td>SMA Umum</td>
                                <td>9.86</td>
                                <td>9.09</td>
                                <td>8.57</td>
                            </tr>
                            <tr>
                                <td>SMA Kejuruan</td>
                                <td>13.55</td>
                                <td>11.13</td>
                                <td>9.42</td>
                            </tr>
                            <tr>
                                <td>Diploma I/II/III</td>
                                <td>8.08</td>
                                <td>5.87</td>
                                <td>4.59</td>
                            </tr>
                            <tr>
                                <td>Universitas</td>
                                <td>7.35</td>
                                <td>5.98</td>
                                <td>4.80</td>
                            </tr>
                        </tbody>
                            
                        </table> -->
                            <br>
                            <div data-aos="fade-up" data-aos-once="false">
                                <div class="mb-12 md:mb-24 rounded-[24px]  p-10 min-w-[21rem] md:min-w-[53rem] sm:min-w-[20rem] text-white min-h-[16rem] md:min-h-[24rem]   mycard hvr-float animate__animated animate__fadeIn"
                                    data-aos="fade-up" data-aos-once="false">
                                    <PendidikanChart />
                                    <span class="text-[14px] md:text-[14px] sm:text-[14px] text-white">Sumber : Survei
                                        Angkatan Kerja Nasional BPS</span>
                                </div>
                            </div>
                            <hr class="custom-hr">
                            
                            <p class="text-[14px] md:text-[24px] sm:text-[14px] mt-4 text-center">
                        <strong>Data seputar pendidikan: <br></strong>
                    </p>
                    <br>
                            <div data-aos="fade-up" data-aos-once="true">
                                <div class="mb-12 mt-2 md:mb-24 rounded-[24px]  p-6 min-w-[21rem] md:min-w-[53rem] sm:min-w-[20rem] text-white    mycard hvr-float animate__animated animate__fadeIn "
                                    data-aos="fade-up" data-aos-once="false">
                                    <div class="flex flex-wrap   space-x-7">
                                        <img src="../assets/section5gambar1.jpg"  alt="" class="infografis-size rounded-[20px]" >
                                        <img src="../assets/section5gambar2.jpg" alt="" class="infografis-size rounded-[20px]">
                                    </div>
                                </div>
                            </div>
                        </p>
                    </div>

                </div>

            </div>
            <br><br>






        </div>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path fill="#00585d" fill-opacity="1"
                d="M0,0L48,37.3C96,75,192,149,288,192C384,235,480,245,576,240C672,235,768,213,864,202.7C960,192,1056,192,1152,170.7C1248,149,1344,107,1392,85.3L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z">
            </path>
        </svg>
    </div>
</template>
<script>
    import PendidikanChart from '../components/5th/PendidikanChart.vue';
    export default {
        props: {
            show1stParagraph: Boolean,
        },
        components: {
            PendidikanChart
        },

        data() {
            return {
                paragraph1st: "Matahari mulai terbenam di balik bukit. Kamingsun keluar menggunakan motor butut modif miliknya lengkap dengan perkakasnya. Kamingsun adalah salah satu peserta balap liar yang akan bertanding di jalur maut flyover.                    Bendera mulai dikibarkan tanda balap liar dimulai.",
                paragraph2nd: "Kamingsun terlalu banyak gaya, beberapa kali dia melakukan standing dengan motornya. Saat 50 meter lagi menuju garis finish, lagi - lagi Kamingsun banyak gaya, dia melakukan standing dengan motornya.             Tidak disangka, motornya slip, Kamingsun terseret dengan motornya di aspal jalur maut. Kamingsun dilarikan ke UGD rumah sakit terdekat. Semenjak kejadian itu Kamingsun mulai merenungi keseharian aktivitas tidak bergunanya.",
                typedText: "",
                typedText2: "",
                showTypingAnimation: true,
                showTypingAnimation2: false,
                showjudulSingkat: false,
                showJudulLengkap: true,
                showMotor: false,
                show1stParagraph: true,
                show2ndParagraph: false,
                enterMotor: "animate__animated animate__slideInLeft",
                exitMotor: "",
                finalExit: null,
                showHospital: false,
                //chart
                chartData: {
                    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
                    datasets: [{
                        label: 'My Chart Data',
                        borderColor: 'rgb(75, 192, 192)',
                        data: [65, 59, 80, 81, 56, 55, 40],
                    }, ],
                },

            };
        },
    }
</script>
<style scoped>
    .custom-hr {
        border: none;
        /* Remove the default solid line */
        border-top: 4px dashed;
        /* Apply a 2px dashed line with a color (#333) */
    }

    .center-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
        /* This will make the container take up the full height of the viewport */
    }

    .full-page {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        min-width: 100vw;
        /* justify-content: center; */
        /* Center content vertically */
        align-items: center;
        /* Center content horizontally */
    }

    .mycard {
        /* border-radius: 18px; */
        background-color: #35374D;
        /* padding: 40px;
        margin-bottom: 20px;
        width: 50%;
        color: black;
        min-height: 360px; */
    }

    .white-background {
        /* background-color: #FFFEC4; */
        background-color: #466969;
        /* background-image: url('../assets/4thbg.svg');
        background-repeat: no-repeat;
        background-size: cover; */
        /* Set the background color to red */
    }


    .quicksand-font {
        font-family: 'Quicksand', sans-serif;
    }



    .content4th {
        color: white;
        /* font-size: 24px; */

        /* font-weight: 800; */
        text-align: left;
    }

    .lottie-player {
        width: 300px;
        height: 300px;
        /* margin-right: 4px; */
        /* Adjust spacing between animations */
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th,
    td {
        border: 1px solid #ccc;
        padding: 8px;
        text-align: left;
    }

    /* th {
            background-color: #f2f2f2;
        } */


    img {
        max-width: 48%;
        height: auto;
        --animate-duration: 12s;
    }

    @media (max-width: 768px) {
        img {
        max-width: 44%;
        height: auto;
        --animate-duration: 12s;
    }
    }

    /* Float */
    .hvr-float {
        display: inline-block;
        vertical-align: middle;
        -webkit-transform: perspective(1px) translateZ(0);
        transform: perspective(1px) translateZ(0);
        box-shadow: 0 0 100px rgba(0, 0, 0, 0);
        -webkit-transition-duration: 0.3s;
        transition-duration: 0.3s;
        -webkit-transition-property: transform;
        transition-property: transform;
        -webkit-transition-timing-function: ease-out;
        transition-timing-function: ease-out;
    }

    .hvr-float:hover,
    .hvr-float:focus,
    .hvr-float:active {
        -webkit-transform: translateY(-20px);
        transform: translateY(-20px);
    }
</style>