<template>
    <div class="full-page white-background">

        <div class="quicksand-font">
            <div class="grid grid-cols-12 gap-4 ">
                <div
                    class="col-start-2 col-end-12 md:col-start-4 md:col-end-10 sm:col-start-2 sm:col-end-12 col-span-6 flex flex-col items-center">
                    <div data-aos="fade-up" data-aos-once="false">
                    <div
                        class="mt-8 md:mt-2 text-2xl md:text-6xl sm:text-2xl font-extrabold  text-center text-white">
                        Sumber</div>
                        </div>
                </div>
                <div class="col-start-3 col-end-11 md:col-start-4 md:col-end-10  flex flex-col items-center">
                    
                    <br><br>
                    <div data-aos="fade-up" data-aos-once="false">
                    <p class="text-[14px] md:text-[24px] sm:text-[14px] mt-4 text-left">
                        Kajian
                        <ul role="list" class="marker:text-sky-400 list-disc pl-5 space-y-3 ">
                            <li>Febryanna, S. 2022. Pola Karakteristik NEET Dan Pengaruh Pengetahuan Pemuda Tentang Program Kartu Prakerja Terhadap Status NEET Di Masa Pandemi Covid-19. Jakarta:Seminar Nasional Official Statistics 2022.</li>
                            <li>Naraswati, NPG dan Jatmiko,Y A. 2021. Individual and Province-level Determinants of Unemployed NEET as Young People’s Productivity Indicator in Indonesia during 2020: A Multilevel Analysis Approach. Jakarta : ICDSOS.</li>
                            <li><a href="https://www.kompas.com/skola/read/2021/07/02/141803269/rasio-ketergantungan-definisi-dampak-fungsi-dan-cara-menghitung">Rasio Ketergantungan: Definisi, Dampak, Fungsi, dan Cara Menghitung </a></li>
                            <li><a href="https://journal.ugm.ac.id/mgi/article/view/59391/34553">Sari, N.R., Sukamdi, S., & Rofi, A. (2022). Distribusi dan Karakteristik Pemuda NEET di Indonesia (Analisis Data Sakernas 2018). Majalah Geografi Indonesia.</a></li>
                            <li><a href="https://doi.org/10.37145/jak.v2i2.34">Setiawan, S. (2019). MENGOPTIMALKAN BONUS DEMOGRAFI UNTUK MENGURANGI TINGKAT KEMISKINAN DI INDONESIA. Jurnal Analis Kebijakan, 2(2). https://doi.org/10.37145/jak.v2i2.34</a></li>
                            
                        </ul>
                        <br>
                        Data
                        <ul role="list" class="marker:text-sky-400 list-disc pl-5 space-y-3 ">
                            <li><a href="https://www.bps.go.id/indikator/indikator/view_data_pub/0000/api_pub/YW40a21pdTU1cnJxOGt6dm43ZEdoZz09/da_03/1">Jumlah Penduduk Menurut Kelompok Umur dan Jenis Kelamin, 2022</a></li>
                            <li><a href="https://www.bps.go.id/indicator/6/1186/1/persentase-usia-muda-15-24-tahun-yang-sedang-tidak-sekolah-bekerja-atau-mengikuti-pelatihan.html">Persentase Usia Muda (15-24 Tahun) Yang Sedang Tidak Sekolah, Bekerja Atau Mengikuti Pelatihan (Persen), 2020-2022</a></li>
                            <li><a href="https://data.worldbank.org/"> Share of youth not in education, employment or training, total (% of youth population) | Data (worldbank.org) </a></li>
                            <li> <a href="https://sensus.bps.go.id">Sensus Penduduk 2020 - Badan Pusat Statistik (bps.go.id)</a></li>
                            <li> <a href="https://siapkerja.kemnaker.go.id">SIAPkerja : Kementerian Ketenagakerjaan Republik Indonesia (kemnaker.go.id)</a> </li>                            
                            <li> <a href="https://www.bps.go.id/publication/2021/12/21/52333d2ce0a748fff6469811/statistik-pemuda-indonesia-2021.html">Statistik Pemuda Indonesia 2021</a> </li>                            
                            <li> <a href="https://www.bps.go.id/publication/2022/11/17/76d9e38c1a9fe738a2dcde75/statistik-kesejahteraan-rakyat-2022.html">Statistik Kesejahteraan Rakyat 2022</a> </li>                            
                        </ul>

                        <br>
                        Assets
                        <ul role="list" class="marker:text-sky-400 list-disc pl-5 space-y-3 ">
                            <li><a href="https://www.flaticon.com/free-icon/salad_2255683">Icon Karedok</a></li>
                            <li><a href="https://www.freepik.com/free-vector/city-skyline-landmarks-illustration_11852626.htm">Gambar Kota di Malam Hari</a></li>
                            <li><a href="https://lottiefiles.com/animations/go-fix-ZJ6B2lbprU">Animasi Motor</a></li>
                            <li><a href="https://lottiefiles.com/animations/sad-guy-is-walking-8qw9i9BtHa">Animasi Pekerja 1</a></li>
                            <li><a href="https://lottiefiles.com/animations/walking-man-QVzioUsMvH">Animasi Pekerja 2</a></li>
                            <li><a href="https://lottiefiles.com/animations/thinking-1tVAwT5uXV">Animasi Berpikir</a></li>
                            <!-- <li><a href="https://www.flaticon.com/free-icon/bacteria_1097326">Icon Covid</a></li>
                            <li><a href="https://www.flaticon.com/free-icon/analytics_943126">Icon Karakteristik di Komputer</a></li> -->
                            <li><a href="https://lottiefiles.com/animations/education-edit-gdzg7fXIzh">Animasi Pendidikan</a></li>
                            <li><a href="https://lottiefiles.com/animations/bonusgiftsuccess-ATgCIxqq1g">Animasi Bonus</a></li>
                            <li><a href="https://lottiefiles.com/animations/people-interacting-with-charts-and-analyzing-statistics-PT0aOP5Uxb">Animasi Peran Pemerintah dan Komunitas</a></li>
                            <li><a href="https://lottiefiles.com/animations/education-new-color-scheme-1Zn1bs15mL">Animasi Belajar</a></li>
                            <li><a href="https://lottiefiles.com/animations/wizzard-sushi-vqU6rb7ZbC">Animasi Penyihir</a></li>
                            <li><a href="https://pixabay.com/music/acoustic-group-a-small-miracle-132333">Musik - A Small Miracle</a></li>
                            <li>Seluruh Infografis dibuat oleh Tim</li>
                        </ul>
                        <br>
                        Tools
                        <ul role="list" class="marker:text-sky-400 list-disc pl-5 space-y-3 ">
                            <li>Vite</li>
                            <li>Vue</li>
                            <li>Tailwind</li>
                            <li>Canva</li>
                            <li>etc</li>
                        </ul>
                        <br>
                        Tim Pegawai Pemberani
                        <ul role="list" class="marker:text-sky-400 list-disc pl-5 space-y-3 ">
                            <li>Afifatul Ilma Widyatami</li>
                            <li>Imam Satya Wedhatama</li>
                        </ul>
                        <br>
                        <hr class="custom-hr mt-4">
                    </p>
                    </div>
                    
                    
                    <p class="text-base md:text-xl mb-4"> 
                        <br>
                        Luaskan ilmu, luaskan manfaat <br>
                        [ ] dengan <span class="animate__animated animate__fadeIn animate__infinite text-red-600 hvr-grow "> ❤ </span> di <br>
                        Jakarta/Solok
                    </p>
                    
                </div>
            </div>
            


           




        </div>
    </div>
</template>
<script>
    import PiramidaPendudukChart from '../components/6th/PiramidaPenduduk.vue';
    export default {
        props: {
            show1stParagraph: Boolean,
        },
        components: {
            PiramidaPendudukChart
        },

        data() {
            return {
                paragraph1st: "Matahari mulai terbenam di balik bukit. Kamingsun keluar menggunakan motor butut modif miliknya lengkap dengan perkakasnya. Kamingsun adalah salah satu peserta balap liar yang akan bertanding di jalur maut flyover.                    Bendera mulai dikibarkan tanda balap liar dimulai.",
                paragraph2nd: "Kamingsun terlalu banyak gaya, beberapa kali dia melakukan standing dengan motornya. Saat 50 meter lagi menuju garis finish, lagi - lagi Kamingsun banyak gaya, dia melakukan standing dengan motornya.             Tidak disangka, motornya slip, Kamingsun terseret dengan motornya di aspal jalur maut. Kamingsun dilarikan ke UGD rumah sakit terdekat. Semenjak kejadian itu Kamingsun mulai merenungi keseharian aktivitas tidak bergunanya.",
                typedText: "",
                typedText2: "",
                showTypingAnimation: true,
                showTypingAnimation2: false,
                showjudulSingkat: false,
                showJudulLengkap: true,
                showMotor: false,
                show1stParagraph: true,
                show2ndParagraph: false,
                enterMotor: "animate__animated animate__slideInLeft",
                exitMotor: "",
                finalExit: null,
                showHospital: false,
                //chart
                chartData: {
                    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
                    datasets: [{
                        label: 'My Chart Data',
                        borderColor: 'rgb(75, 192, 192)',
                        data: [65, 59, 80, 81, 56, 55, 40],
                    }, ],
                },

            };
        },
    }
</script>
<style scoped>
    .full-page {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        min-width: 100vw;
        /* justify-content: center; */
        /* Center content vertically */
        align-items: center;
        /* Center content horizontally */
    }
    
    .custom-hr {
        
        border: 2px solid; 
    }

    .mycard {
        border-radius: 18px;
        background-color: white;
        padding: 40px;
        margin-bottom: 20px;
        width: 50%;
        color: black;
        min-height: 360px;
    }

    .white-background {
        /* background-color: #FFFEC4; */
        background-color: #222837;
        /* background-image: url('../assets/4thbg.svg');
        background-repeat: no-repeat;
        background-size: cover; */
        /* Set the background color to red */
    }
   
    .quicksand-font {
        font-family: 'Quicksand', sans-serif;
    }

    .judul4th {
        margin-top: 2%;
        margin-left: 10%;
        margin-right: 10%;
        font-size: 60px;
        color: white;
        font-weight: 900;
    }

    .content4th {
        color: white;
        font-size: 24px;

        font-weight: 800;
        text-align: left;
    }

    .lottie-player {
        width: 300px;
        height: 300px;
        margin-right: 4px;
        /* Adjust spacing between animations */
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th,
    td {
        border: 1px solid #ccc;
        padding: 8px;
        text-align: left;
    }

    /* th {
            background-color: #f2f2f2;
        } */
        .hvr-grow {
            display: inline-block;
            vertical-align: middle;
            -webkit-transform: perspective(1px) translateZ(0);
            transform: perspective(1px) translateZ(0);
            box-shadow: 0 0 1px rgba(0, 0, 0, 0);
            -webkit-transition-duration: 0.3s;
            transition-duration: 0.3s;
            -webkit-transition-property: transform;
            transition-property: transform;
        }
        .hvr-grow:hover, .hvr-grow:focus, .hvr-grow:active {
        -webkit-transform: scale(1.4);
        transform: scale(1.4);
        }

    img {
        max-width: 30%;
        height: auto;
        --animate-duration: 12s;
    }
</style>